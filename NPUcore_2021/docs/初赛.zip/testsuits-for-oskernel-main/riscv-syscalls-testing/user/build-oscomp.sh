#!/bin/bash

make all CHAPTER=7

sync
