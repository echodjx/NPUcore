// See LICENSE for license details.

#ifndef _BBL_H
#define _BBL_H

#ifndef __ASSEMBLER__

#include <stdint.h>
#include <stddef.h>

void print_logo();

#endif // !__ASSEMBLER__

#endif
