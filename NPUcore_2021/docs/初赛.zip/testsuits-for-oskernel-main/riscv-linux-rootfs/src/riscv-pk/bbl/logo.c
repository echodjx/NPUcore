// See LICENSE for license details.

#include <string.h>
#include "mtrap.h"

extern const char logo[];

void print_logo()
{
  putstring(logo);
}
