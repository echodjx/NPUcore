// See LICENSE for license details.

#ifndef DISABLED_HART_MASK_H
#define DISABLED_HART_MASK_H
extern long disabled_hart_mask;
#endif
